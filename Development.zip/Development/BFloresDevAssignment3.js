/*
    Author: Bryan Flores
    Date: 12/9/2021
*/

var express = require('express');
var bParser = require('body-parser');
var app = express();
var MongoClient = require('mongodb').MongoClient

var counter = 0;

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.use(bParser.urlencoded({ extended: true}));

app.use(express.static(__dirname + '/'));

/////////////////////////////////////////////////////////////////////////////////////////////
                          // for log in page (get and post)
/////////////////////////////////////////////////////////////////////////////////////////////
app.get('/', function (req, res) {
  res.sendFile(__dirname + '/dev3static.html');
});

app.post('/login', function(req, res) {
  var checkUser = req.body.userName;
  var checkPass = req.body.passWord;
  MongoClient.connect('mongodb://localhost:27017/accounts', function (err, db) {
    if (err) throw err

    var dbLoginAcc = db.collection('users');
    dbLoginAcc.findOne({'username':checkUser}, function (err, document) {
      if(err) {
        var htmlWrongUser = 
          "<form action='/' method='get'>" +
          "Return to login page <br>" +
          "<button type='submit'>Return</button>" +
          "</form>" +
          "<form action='/createacc' method='get'>" +
          "Register an account <br>" +
          "<button type='submit'>Register</button> <br> <br>";
        res.send(htmlWrongUser);
      }      
      else if(checkPass != document.password) {
        res.send(htmlWrongUser);
      }
      else {
        var htmlSuccessLogin =
          "<h1>Welcome, " + document.firstname + " " + document.lastname + "!</h1>" +
          "<form action='tasks' method='get'>" +
          "Click below to enter the Tasks Page <br>" +
          "<button type='submit'>Tasks</button> <br>" +
          "</form>";
        res.send(htmlSuccessLogin);
      }
      db.close();
    });
  });
});

/////////////////////////////////////////////////////////////////////////////////////////////
                          // for tasks page (get and post)
/////////////////////////////////////////////////////////////////////////////////////////////
app.get('/tasks', function (req, res) {
  var htmlTasks =
    "<form action='/tasks' method='post'>" +
    "Enter a text that will be added to your account <br>" +
    "<input type='text' name='userText'> <br>" +
    "Please enter your correct username below <br>" +
    "<input type='text' name='userName'> <br>" +
    "<button type='submit'>Add Text</button> <br> <br>"
    "</form>";
    res.send(htmlTasks);
});

app.post('/tasks', function (req, res) {
  var checkUser = req.body.userName;
  var loginTask = req.body.userText;
  MongoClient.connect('mongodb://localhost:27017/accounts', function (err, db) {
    if (err) throw (err)
    var dbLoginAcc = db.collection('users');
    var htmlDefault =
      "Below is the text added to your profile.<br>" +
      loginTask + "<br>" +
      "<form action='/login' method='post'>" +
      "Return to account home page <br>" +
      "<button type='submit'>Return</button> <br>" +
      "</form>";
    dbLoginAcc.findOne({'username':checkUser}, function (err, document) {
      if (err) {
        console.log(err);
        return console.log(err);
      }
      else {
        document.text = loginTask;
        res.send(htmlDefault);
      }
    })
  })
})

/////////////////////////////////////////////////////////////////////////////////////////////
                          // for create account page (get and post)
/////////////////////////////////////////////////////////////////////////////////////////////
app.get('/createacc', function (req, res) {
    var htmlCreate = 
      "<img src='SomberSpirit.PNG' />" +
      "<h2>Register an account below.</h2>" +
      "<form action='/create' method='post'>" +
      "Username: " +
      "<input type='text' name='userName'> <br>" +
      "Password: " + 
      "<input type='password' name='passWord'> <br>" +
      "First name: " +
      "<input type='text' name='firstName'> <br>" +
      "Last name: " +
      "<input type='text' name='lastName'> <br>" +
      "Email: " +
      "<input type='text' name='email'> <br>" +
      "<button type='submit'>Register</button> <br><br>"
      "</form>";
  res.send(htmlCreate);
});

app.post('/create', function(req,res) {
  var loginUser = req.body.userName;
  var loginPass = req.body.passWord;
  var loginFirst = req.body.firstName;
  var loginLast = req.body.lastName;
  var loginEmail = req.body.email;
  MongoClient.connect('mongodb://localhost:27017/accounts', function (err, db) {
    if (err) throw err
    var dbLoginAcc = db.collection('users');
    var htmlCreated = 
      "<img src=SomberSpirit.PNG /> <br>" + 
      "<p>The account has been successfully created!</p>" +
      "<form action='/' method='get'>" +
      "Click below to return the log in page <br>" + 
      "<button type='submit'>Return to Log In page</button>";
      counter+=1;
      dbLoginAcc.save({"usernumber":counter, "username":loginUser, "password":loginPass, "firstname":loginFirst, "lastname":loginLast, "email":loginEmail,"text":"sample text"}, function(err, result) {
        dbLoginAcc.find().toArray(function (err, documents) {
          console.log(documents);
          res.send(htmlCreated);
          db.close();
        });
      });
  });
});

app.listen(4001, function () {
    console.log('Listening on port 4001');
  });